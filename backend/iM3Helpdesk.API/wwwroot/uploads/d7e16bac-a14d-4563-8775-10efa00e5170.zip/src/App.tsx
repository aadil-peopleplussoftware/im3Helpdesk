import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Lock, 
  ArrowRight, 
  HelpCircle, 
  UserPlus, 
  LogIn, 
  ChevronLeft,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';

type AuthMode = 'login' | 'signup' | 'forgot-password';

export default function App() {
  const [mode, setMode] = useState<AuthMode>('login');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  const MicrosoftIcon = () => (
    <svg className="w-5 h-5 mr-2" viewBox="0 0 23 23" xmlns="http://www.w3.org/2000/svg">
      <path fill="#f35325" d="M1 1h10v10H1z"/>
      <path fill="#81bc06" d="M12 1h10v10H12z"/>
      <path fill="#05a6f0" d="M1 12h10v10H1z"/>
      <path fill="#ffba08" d="M12 12h10v10H12z"/>
    </svg>
  );

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-blue-500/30 flex overflow-hidden">
      {/* Left Side: Branded Visual */}
      <div className="hidden lg:flex lg:w-1/2 relative p-12 flex-col justify-between overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-blue-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-indigo-600/20 rounded-full blur-[120px]" />
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none" />
        </div>

        <div className="relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center space-x-3"
          >
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20">
              <Zap className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-bold tracking-tight">iM3HelpDesk</span>
          </motion.div>
        </div>

        <div className="relative z-10 max-w-xl">
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="text-6xl font-bold leading-[0.9] tracking-tighter mb-6"
          >
            THE FUTURE OF <br />
            <span className="text-blue-500">SUPPORT</span> IS HERE.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="text-gray-400 text-lg leading-relaxed"
          >
            Streamline your workflow with our intelligent helpdesk solution. 
            Built for scale, designed for speed.
          </motion.p>
        </div>

        <div className="relative z-10 flex items-center space-x-8 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4" />
            <span>Enterprise Grade</span>
          </div>
          <div className="flex items-center space-x-2">
            <Globe className="w-4 h-4" />
            <span>Global Infrastructure</span>
          </div>
        </div>
      </div>

      {/* Right Side: Auth Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 bg-[#0f0f0f] relative">
        {/* Mobile Logo */}
        <div className="absolute top-8 left-8 lg:hidden flex items-center space-x-2">
          <Zap className="text-blue-600 w-6 h-6" />
          <span className="text-xl font-bold tracking-tight">iM3</span>
        </div>

        <motion.div 
          layout
          className="w-full max-w-[440px] space-y-8"
        >
          <AnimatePresence mode="wait">
            {mode === 'login' && (
              <motion.div
                key="login"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tight">Welcome back</h2>
                  <p className="text-gray-400">Enter your credentials to access your account</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-400 ml-1">Email Address</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-blue-500 transition-colors" />
                      <input 
                        type="email" 
                        required
                        placeholder="name@company.com"
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-gray-600"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-sm font-medium text-gray-400">Password</label>
                      <button 
                        type="button"
                        onClick={() => setMode('forgot-password')}
                        className="text-sm text-blue-500 hover:text-blue-400 transition-colors font-medium"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-blue-500 transition-colors" />
                      <input 
                        type="password" 
                        required
                        placeholder="••••••••"
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-gray-600"
                      />
                    </div>
                  </div>

                  <button 
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-blue-600/20 flex items-center justify-center space-x-2 transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <span>Sign in to Dashboard</span>
                        <ArrowRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </form>

                <div className="relative py-4">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-800"></div>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-[#0f0f0f] px-4 text-gray-500 tracking-widest">Or continue with</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <button className="flex items-center justify-center bg-white text-black font-semibold py-4 rounded-2xl hover:bg-gray-100 transition-all active:scale-[0.98]">
                    <MicrosoftIcon />
                    Sign in with Microsoft
                  </button>
                </div>

                <p className="text-center text-gray-500 text-sm">
                  Don't have an account?{' '}
                  <button 
                    onClick={() => setMode('signup')}
                    className="text-blue-500 hover:text-blue-400 font-semibold transition-colors"
                  >
                    Create an account
                  </button>
                </p>
              </motion.div>
            )}

            {mode === 'signup' && (
              <motion.div
                key="signup"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <button 
                    onClick={() => setMode('login')}
                    className="flex items-center text-gray-500 hover:text-white transition-colors text-sm mb-4"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    Back to login
                  </button>
                  <h2 className="text-3xl font-bold tracking-tight">Create account</h2>
                  <p className="text-gray-400">Join iM3HelpDesk and start managing support better</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-400 ml-1">First Name</label>
                      <input 
                        type="text" 
                        required
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 px-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-400 ml-1">Last Name</label>
                      <input 
                        type="text" 
                        required
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 px-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-400 ml-1">Work Email</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-blue-500 transition-colors" />
                      <input 
                        type="email" 
                        required
                        placeholder="name@company.com"
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-400 ml-1">Password</label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-blue-500 transition-colors" />
                      <input 
                        type="password" 
                        required
                        placeholder="Minimum 8 characters"
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>

                  <button 
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-blue-600/20 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
                  >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <span>Create Account</span>
                        <UserPlus className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </form>

                <p className="text-xs text-gray-500 text-center leading-relaxed">
                  By creating an account, you agree to our{' '}
                  <a href="#" className="text-blue-500 hover:underline">Terms of Service</a> and{' '}
                  <a href="#" className="text-blue-500 hover:underline">Privacy Policy</a>.
                </p>
              </motion.div>
            )}

            {mode === 'forgot-password' && (
              <motion.div
                key="forgot"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <button 
                    onClick={() => setMode('login')}
                    className="flex items-center text-gray-500 hover:text-white transition-colors text-sm mb-4"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    Back to login
                  </button>
                  <h2 className="text-3xl font-bold tracking-tight">Reset password</h2>
                  <p className="text-gray-400">Enter your email and we'll send you instructions to reset your password</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-400 ml-1">Email Address</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-blue-500 transition-colors" />
                      <input 
                        type="email" 
                        required
                        placeholder="name@company.com"
                        className="w-full bg-[#1a1a1a] border border-gray-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                  </div>

                  <button 
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-blue-600/20 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
                  >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <span>Send Reset Link</span>
                        <Mail className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </form>

                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-start space-x-3">
                  <HelpCircle className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                  <p className="text-sm text-blue-200/80 leading-relaxed">
                    If you don't receive an email within a few minutes, please check your spam folder or contact support.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Footer Links */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center space-x-6 text-xs text-gray-600">
          <a href="#" className="hover:text-gray-400 transition-colors">Privacy</a>
          <a href="#" className="hover:text-gray-400 transition-colors">Terms</a>
          <a href="#" className="hover:text-gray-400 transition-colors">Contact</a>
        </div>
      </div>
    </div>
  );
}
